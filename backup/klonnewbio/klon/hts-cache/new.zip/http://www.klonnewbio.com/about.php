<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<script src="js/jquery-1.11.0.min.js" type="text/javascript"></script>
<script src="js/responsiveslides.min.js" type="text/javascript"></script>
<title>公司简介--深圳科隆生物新材料有限公司</title>
<meta name="keywords" content="深圳科隆生物新材料有限公司"/>
<meta name="description" content="深圳科隆生物新材料有限公司"/>
<script>
	window.onload = function(){
		document.getElementsByClassName("us")[0].getElementsByTagName("p")[0].innerHTML = "深圳市大鹏新区金业大道140号<br/>国际生物谷生命科学产业园B5栋301<br/>邮编：518000<br/>电话：13537778661<br/><br/>电子邮箱：klonnewbio@klonnewbio.com"
		document.getElementsByClassName("lxwm")[0].innerHTML = "<h3>联系我们</h3><p></p><p>公司名：深圳科隆生物新材料有限公司 <br>联系人：王博士</p><p>	技术咨询热线：13537778661</p><p>售后电话：13537778661</p><p>Email：klonnewbio@klonnewbio.com</p><p>Web： www.klonnewbio.com</p><p></p>"
	}
</script></head>

<body>
	<div class="wrap">
    	
        <!--header-->
        <div class="header">
     <div style="float: right;margin-right: 55px;font-size: 14px;margin-top: 35px;"><a href="#">中文&nbsp;</a>/<a href="en/">&nbsp;English</a></div>
        	<div class="div1200">
            	<div class="logo fl"><a href=""><img src="images/index_05.png" /></a></div>
                <div class="nav fr">
                	<ul>
                    	<li >
                            <a href="index.php">
                                首页
                            </a>
                        </li>
                    	<li class="on">
                            <a href="about.php">
                                关于我们
                            </a>
                        </li>
                    	<li >
                            <a href="product.php">
                                产品中心
                            </a>
                        </li>
                    	<li >
                            <a href="dzfw.php">
                                定制服务
                            </a>
                        </li>
                    	<li >
                            <a href="news.php">
                                新闻动态
                            </a>
                        </li>
                    	<li >
                            <a href="swhz.php">
                                商务合作
                            </a>
                        </li>
                    	<li >
                            <a href="job.php">
                                招贤纳士
                            </a>
                        </li>
                    	<li >
                            <a href="contact.php">
                                联系我们
                            </a>
                        </li>                                                                             
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>

            </div>

        </div>        
        <!--banner-->
            <div class="banner">
                    <img src="upimg/2018070816374956.jpg" />
            </div>
        
        <!--main-->
        <div class="main">
        	<div class="div1200">
            	<div class="main_tit">
            		<span>当前位置：<a href="index.php">首页</a>   >   <a href="about.php">关于我们</a>       &gt; 公司简介</span>
                </div>
            </div>
        </div>
       
        
        <!--产品详情-->
        <div class="product">
        	<div class="div1200">
            	<div class="tit">
                	<h1>关于我们</h1>
                    <p class="slideInUp wow animated">搜索超过30000种的诊断原料</p>
                </div>
                <div class="search">
                	<div class="search_form">
                    	<form method="get">
                        	<input type="text" class="text" name="keyword" placeholder="请输入搜索关键字" />
                            <input type="submit" value="" class="btn" />
                        </form>
                    </div>
                </div>
                <div class="product_list">
                	<div class="product_a fl">
	<div class="product_box">
        <ul>
            <!--一级-->
                        <li class="on">
                <a href="about.php?id=1">
                    公司简介                </a>
            </li>
                    <li >
                <a href="about.php?id=3">
                    企业文化                </a>
            </li>
                </ul>
    </div>
   
    
    <!--左边联系我们-->
    <div class="content">
    	<h3>CONTACT US​</h3>
        <div class="net">
        	<ul>
                                	<li>
                    	<div class="net_a fl">
                            <img src="upimg/2018070817340945.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                地址：深圳市大鹏新区金业大道140号<br />国际生物谷生命科学产业园B5栋301                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	                	<li>
                    	<div class="net_a fl">
                            <img src="upimg/2018070817344368.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                邮箱地址： 	klonnewbio@klonnewbio.com&nbsp;                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	                	<li>
                    	<div class="net_a fl">
                            <img src="upimg/2018070817411024.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                联系方式：<br />13537778661 王博士                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	                	<li>
                    	<div class="net_a fl">
                            <img src="upimg/2018070817414425.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	            </ul>
        </div>
    </div></div>

                    <div class="xq fr">
                    	
                        <div class="xq_content">
                        	<div class="b"></div>
                        	
                            <div class="xq_nr">
                                <h2 style="margin-top: 20px;">公司简介</h2>
                            	<p style="margin-top: 30px; font-size: 18px;"></p>
                            </div>
                        </div>
                       
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
        
        <!--联系我们  深圳科隆生物新材料有限公司-->
<div class="us">
	<div class="div1200">
    	<div class="us_a fl">
        	<h1>联系我们</h1>
            <div class="us_form">
            	 <form name="formb" id="formb" method="post" action="message.php?act=post" onsubmit="return checkform('formb')">
                	<input type="text" class="text1" placeholder="姓名" style="color:#fff;" name="rename" />
                    <select class="select" name="title">
                    	<option style="color:#c7cccc;" value="">选择国别</option>
                                            	<option style="color:#c7cccc;" value="中国">中国</option>
                                            </select>
                	<input type="text" class="text1" placeholder="公司名称" style="color:#fff;" name="compname" />
                	<input type="text" class="text1 text2" placeholder="邮箱" style="color:#fff;" name="email" />
                    <textarea class="textarea" placeholder="你的信息" style="color:#fff;" name="z_body"></textarea>
                    <input type="submit" class="lxwm_btn fr" value="提交" />
                    <div class="clear"></div>
                </form>
            </div>
        </div>

        <!--底部联系我们-->
        <div class="us_b fl">

        	        	<h1>深圳科隆生物新材料有限公司</h1>
            <p>
            	深圳市大鹏新区金业大道140号<br />国际生物谷生命科学产业园B5栋3层<br />邮编 518000 <br />电话: 13537778661 王博士<br /><br />电子邮件:<br />klonnewbio@klonnewbio.com<br />+86-13537778661<br /><br />订货:<br />klonnewbio@klonnewbio.com            </p>
        </div>
        <div class="clear"></div>
    </div>
</div>

<div class="foot">
    	<div class="div1200">
        	<p>&copy; Copyright 2018 深圳科隆生物新材料有限公司 <a href="http://www.miit.gov.cn/" target="_blank">粤ICP备18065683号-1号</a> 网站建设：<a href="http://www.heyou51.com" target="_blank">合优网络</a></p>
        </div>
    </div>
</div></body>
</html>
