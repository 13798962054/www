<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<script src="js/jquery-1.11.0.min.js" type="text/javascript"></script>
<script src="js/responsiveslides.min.js" type="text/javascript"></script>
<title>Custom service</title>
<meta name="keywords" content=""/>
<meta name="description" content=""/>
<script>
	window.onload = function(){
		document.getElementsByClassName("us")[0].getElementsByTagName("p")[0].innerHTML = "301,Block 5,Bio Vally Bioscience<br/>Industrial Park,Jinye Rd. 140.<br/>Zip code：518000<br/>Phone：13537778661 Dr.wang<br/><br/>Email：klonnewbio@klonnewbio.com"
		document.getElementsByClassName("lxwm")[0].innerHTML = '<h3>contact us</h3><p><span id="result_box" class=""><span class=""><span style="font-size:14px;"><span>Shenzhen Klon New Biomaterials Co., Ltd. </span></span><br><span style="font-size:14px;"> Contact: Dr. Wang</span></span><br><span class="" style="font-size:14px;">Technical Advisory Hotline: 13537778661</span><br><span class="" style="font-size:14px;">After-sales phone: 13537778661</span><br><span style="font-size:12px;"><span style="font-size:14px;">Email: klonnewbio@klonnewbio.com</span><span style="font-size:14px;"></span></span><br><span class="" style="font-size:14px;">Web: www.klonnewbio.com</span></span></p>'
	}
</script></head>

<body>
	<div class="wrap">
    	
        <!--header-->
        <div class="header">
     <div style="float: right;margin-right: 55px;font-size: 14px;margin-top: 35px;"><a href="../">中文&nbsp;</a>/<a href="#">&nbsp;English</a></div>
        	<div class="div1200">
            	<div class="logo fl"><a href=""><img src="images/index_05.png" /></a></div>
                <div class="nav fr">
                	<ul>
                    	<li >
                            <a href="index.php">
                                Home
                            </a>
                        </li>
                    	<li >
                            <a href="about.php">
                                About
                            </a>
                        </li>
                    	<li >
                            <a href="product.php">
                                Product
                            </a>
                        </li>
                    	<li class="on">
                            <a href="dzfw.php">
                                Custom
                            </a>
                        </li>
                    	<li >
                            <a href="news.php">
                                News
                            </a>
                        </li>
                    	<li >
                            <a href="swhz.php">
                                Business
                            </a>
                        </li>
                    	<li >
                            <a href="job.php">
                                Careers
                            </a>
                        </li>
                    	<li >
                            <a href="contact.php">
                                Contact
                            </a>
                        </li>                                                                             
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>        
        <!--banner-->
            <div class="banner">
                    <img src="../upimg/2018070816374956.jpg" />
            </div>
        
        <!--main-->
        <div class="main">
        	<div class="div1200">
            	<div class="main_tit">
            		<span>current location:<a href="index.php">Home</a>   >   <a href="dzfw.php">Custom service</a>       &gt; Custom service</span>
                </div>
            </div>
        </div>
       
        
        <!--产品详情-->
        <div class="product">
        	<div class="div1200">
            	<div class="tit">
                	<h1>Custom service</h1>
                    <p class="slideInUp wow animated">Search over 30,000 diagnostic materials</p>
                </div>
                <div class="search">
                	<div class="search_form">
                    	<form method="get">
                        	<input type="text" class="text" name="keyword" placeholder="Please enter your search keywords" />
                            <input type="submit" value="" class="btn" />
                        </form>
                    </div>
                </div>
                <div class="product_list">
                	<div class="product_a fl">
                        <div class="product_box">
                            <ul>
                                <!--一级-->
                                                                <li class="on">
                                    <a href="about.php?id=8">
                                        Custom service                                    </a>
                                </li>
                                                        </ul>
                        </div>
                       
                        
                        <!--左边联系我们-->
                        <div class="content">
    	<h3>CONTACT US​</h3>
        <div class="net">
        	<ul>
                                	<li>
                    	<div class="net_a fl">
                            <img src="../upimg/2018070817340945.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                Address:<br /><br />301,Block 5,Bio Vally Bioscience<br />Industrial Park,Jinye Rd. 140.                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	                	<li>
                    	<div class="net_a fl">
                            <img src="../upimg/2018070817344368.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                email address： 	klonnewbio@klonnewbio.com&nbsp;                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	                	<li>
                    	<div class="net_a fl">
                            <img src="../upimg/2018070817411024.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                Contact information:<br />13537778661 Dr.wang                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	                	<li>
                    	<div class="net_a fl">
                            <img src="../upimg/2018070817414425.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	            </ul>
        </div>
    </div>                    </div>



                    <div class="xq fr">
                    	
                        <div class="xq_content">
                        	<div class="b"></div>
                        	
                            <div class="xq_nr">
                                <h2>Custom service</h2>
                            	<span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span><span id="result_box" class="short_text"><span class="">Custom service</span></span>                            </div>
                        </div>
                       
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
        
        <!--联系我们  深圳科隆生物新材料有限公司-->
<div class="us">
	<div class="div1200">
    	<div class="us_a fl">
        	<h1>contact us</h1>
            <div class="us_form">
            	 <form name="formb" id="formb" method="post" action="message.php?act=post" onsubmit="return checkform('formb')">
                	<input type="text" class="text1" placeholder="Name" style="color:#fff;" name="rename" />
                    <select class="select" name="title">
                    	<option style="color:#c7cccc;" value="">Choose country</option>
                                            	<option style="color:#c7cccc;" value="China">China</option>
                                            </select>
                	<input type="text" class="text1" placeholder="company name" style="color:#fff;" name="compname" />
                	<input type="text" class="text1 text2" placeholder="mailbox" style="color:#fff;" name="email" />
                    <textarea class="textarea" placeholder="Your information" style="color:#fff;" name="z_body"></textarea>
                    <input type="submit" class="lxwm_btn fr" value="submit" />
                    <div class="clear"></div>
                </form>
            </div>
        </div>

        <!--底部联系我们-->
        <div class="us_b fl">

        	        	<h1>Shenzhen Klon New Biomaterials Co., Ltd. </h1>
            <p>
            	Floor 3,Block 5,Bio Vally Bioscience<br />Industrial Park,Jinye Rd. 140.<br /><br />Zip code: 518000<br /><br />Phone: 13537778661 Dr.wang<br />            </p>
        </div>
        <div class="clear"></div>
    </div>
</div>

<div class="foot">
    	<div class="div1200">
        	<p></p>
        </div>
    </div>
</div></body>
</html>
