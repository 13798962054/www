<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<script src="js/jquery-1.11.0.min.js" type="text/javascript"></script>
<script src="js/responsiveslides.min.js" type="text/javascript"></script>
<title></title>
<meta name="keywords" content=""/>
<meta name="description" content=""/>
<script>
	window.onload = function(){
		document.getElementsByClassName("us")[0].getElementsByTagName("p")[0].innerHTML = "301,Block 5,Bio Vally Bioscience<br/>Industrial Park,Jinye Rd. 140.<br/>Zip code：518000<br/>Phone：13537778661 Dr.wang<br/><br/>Email：klonnewbio@klonnewbio.com"
		document.getElementsByClassName("lxwm")[0].innerHTML = '<h3>contact us</h3><p><span id="result_box" class=""><span class=""><span style="font-size:14px;"><span>Shenzhen Klon New Biomaterials Co., Ltd. </span></span><br><span style="font-size:14px;"> Contact: Dr. Wang</span></span><br><span class="" style="font-size:14px;">Technical Advisory Hotline: 13537778661</span><br><span class="" style="font-size:14px;">After-sales phone: 13537778661</span><br><span style="font-size:12px;"><span style="font-size:14px;">Email: klonnewbio@klonnewbio.com</span><span style="font-size:14px;"></span></span><br><span class="" style="font-size:14px;">Web: www.klonnewbio.com</span></span></p>'
	}
</script></head>

<body>
	<div class="wrap">
    	
        <!--header-->
        <div class="header">
     <div style="float: right;margin-right: 55px;font-size: 14px;margin-top: 35px;"><a href="../">中文&nbsp;</a>/<a href="#">&nbsp;English</a></div>
        	<div class="div1200">
            	<div class="logo fl"><a href=""><img src="images/index_05.png" /></a></div>
                <div class="nav fr">
                	<ul>
                    	<li >
                            <a href="index.php">
                                Home
                            </a>
                        </li>
                    	<li >
                            <a href="about.php">
                                About
                            </a>
                        </li>
                    	<li class="on">
                            <a href="product.php">
                                Product
                            </a>
                        </li>
                    	<li >
                            <a href="dzfw.php">
                                Custom
                            </a>
                        </li>
                    	<li >
                            <a href="news.php">
                                News
                            </a>
                        </li>
                    	<li >
                            <a href="swhz.php">
                                Business
                            </a>
                        </li>
                    	<li >
                            <a href="job.php">
                                Careers
                            </a>
                        </li>
                    	<li >
                            <a href="contact.php">
                                Contact
                            </a>
                        </li>                                                                             
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>        
        <!--banner-->
            <div class="banner">
                    <img src="../upimg/2018070816374956.jpg" />
            </div>
        
        <!--main-->
        <div class="main">
        	<div class="div1200">
            	<div class="main_tit">
            		<span>current location:<a href="index.php">Home</a>   >   <a href="product.php">Product center</a>    >   </span>
                </div>
            </div>
        </div>
       
        
        <!--产品中心-->
        <div class="product">
        	<div class="div1200">
            	<div class="tit">
                	<h1>Product center</h1>
                    <p class="slideInUp wow animated">Search over 30,000 diagnostic materials</p>
                </div>
                <div class="search">
                	<div class="search_form">
                    	<form method="get">
                        	<input type="text" class="text" name="keyword" placeholder="Please enter your search keywords" />
                            <input type="submit" value="" class="btn" />
                        </form>
                    </div>
                </div>
                <div class="product_list">
                	<div class="product_a fl">
	<div class="product_box">
        <ul>
            <!--一级-->
                        <li >
                <a href="javascript:;">
                    Eugenics ToRCH Series                </a>

                            <ul class="two">
                                <li>
                    <!--2级标题-->
                	<p>antigen</p>

                                            <!--3级标题-->
                        <a href="product.php?lm=13" class="sanji">- Natural antigen</a>
                                                <!--3级标题-->
                        <a href="product.php?lm=14" class="sanji">- Recombinant antigen</a>
                                                
                </li>
                                <li>
                    <!--2级标题-->
                	<p>antibody</p>

                                            <!--3级标题-->
                        <a href="product.php?lm=11" class="sanji">- Polyclonal antibody</a>
                                                <!--3级标题-->
                        <a href="javascript:;" class="sanji">- Monoclonal antibodies</a>
                                                
                </li>
                                
                                <div class="yc">
                	<ul>
                                            	<li>
                            <p>
                                Applicable platform                            </p>

                                                        <a href="product.php?lm=16">
                                - Enzyme free                            </a>
                                                        <a href="product.php?lm=17">
                                - Chemiluminescence                            </a>
                                                        <a href="product.php?lm=18">
                                - Immunohistochemistry                            </a>
                                                        <a href="product.php?lm=19">
                                - Lateral tomography                            </a>
                                                        <a href="product.php?lm=20">
                                - Western blot                            </a>
                                                        <a href="product.php?lm=21">
                                - other                            </a>
                                                                      
                        </li>
                    	                    	<li>
                            <p>
                                Antibody type                            </p>

                                                        <a href="product.php?lm=23">
                                - Primary antibody                            </a>
                                                        <a href="product.php?lm=24">
                                - Secondary antibody                            </a>
                                                        <a href="product.php?lm=25">
                                - other                            </a>
                                                                      
                        </li>
                    	                    	<li>
                            <p>
                                Antibody subtype                            </p>

                                                        <a href="product.php?lm=27">
                                - lgA                            </a>
                                                        <a href="product.php?lm=28">
                                - lgM                            </a>
                                                        <a href="product.php?lm=29">
                                - lgG                            </a>
                                                        <a href="product.php?lm=30">
                                - lgE                            </a>
                                                        <a href="product.php?lm=31">
                                - lgD                            </a>
                                                        <a href="product.php?lm=32">
                                - other                            </a>
                                                                      
                        </li>
                    	                    	<li>
                            <p>
                                Antibody technology                            </p>

                                                        <a href="product.php?lm=34">
                                - Hybridoma antibody                            </a>
                                                        <a href="product.php?lm=35">
                                - Recombinant antibody                            </a>
                                                        <a href="product.php?lm=36">
                                - other                            </a>
                                                                      
                        </li>
                    	                    	<li>
                            <p>
                                Antibody generation                            </p>

                                                        <a href="product.php?lm=38">
                                - generation                            </a>
                                                        <a href="product.php?lm=39">
                                - Second generation                            </a>
                                                        <a href="product.php?lm=40">
                                - Four generations                            </a>
                                                                      
                        </li>
                    	                    	<li>
                            <p>
                                Source of protest                            </p>

                                                        <a href="product.php?lm=42">
                                - Source                            </a>
                                                        <a href="product.php?lm=43">
                                - Mouse source                            </a>
                                                        <a href="product.php?lm=44">
                                - Human source                            </a>
                                                        <a href="product.php?lm=45">
                                - other                            </a>
                                                                      
                        </li>
                    	                    </ul>
                </div>
                                 
            </ul>
                    </li>
                    <li >
                <a href="product.php?lm=2">
                    Autoimmune series                </a>

                        </li>
                    <li >
                <a href="product.php?lm=3">
                    Flow series                </a>

                        </li>
                    <li >
                <a href="product.php?lm=4">
                    Cardiovascular series                </a>

                        </li>
                    <li >
                <a href="product.php?lm=5">
                    Tumor series                </a>

                        </li>
                    <li >
                <a href="product.php?lm=6">
                    Infectious disease series                </a>

                        </li>
                    <li >
                <a href="product.php?lm=7">
                    Pathology series                </a>

                        </li>
                    <li >
                <a href="product.php?lm=8">
                    Other diseases series                </a>

                        </li>
                </ul>
    </div>
    <script>
		$(".product_box > ul > li > .two > li .sanji").click(function(){
			$(".yc").slideToggle(200);	
		})
	</script>
    
    <!--左边联系我们-->
    <div class="content">
    	<h3>CONTACT US​</h3>
        <div class="net">
        	<ul>
                                	<li>
                    	<div class="net_a fl">
                            <img src="../upimg/2018070817340945.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                Address:<br /><br />301,Block 5,Bio Vally Bioscience<br />Industrial Park,Jinye Rd. 140.                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	                	<li>
                    	<div class="net_a fl">
                            <img src="../upimg/2018070817344368.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                email address： 	klonnewbio@klonnewbio.com&nbsp;                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	                	<li>
                    	<div class="net_a fl">
                            <img src="../upimg/2018070817411024.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                Contact information:<br />13537778661 Dr.wang                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	                	<li>
                    	<div class="net_a fl">
                            <img src="../upimg/2018070817414425.png" />
                        </div>
                        <div class="net_b fl">
                            <p>
                                                            </p>
                        </div>
                        <div class="clear"></div>
                    </li>
            	            </ul>
        </div>
    </div></div>                    <div class="product_b fr">
                    	<ul>
                                                        	<li>
                                	<a href="product_show.php?id=9">
                                    	<div class="pro_img">
                                            <img src="../upimg/2018070812474069.png" />
                                        </div>
                                        <p>Flow series</p>
                                    </a>
                                </li>
                        	                            	<li>
                                	<a href="product_show.php?id=8">
                                    	<div class="pro_img">
                                            <img src="../upimg/2018070812471966.png" />
                                        </div>
                                        <p>Infectious disease series</p>
                                    </a>
                                </li>
                        	                            	<li>
                                	<a href="product_show.php?id=7">
                                    	<div class="pro_img">
                                            <img src="../upimg/2018070812464486.png" />
                                        </div>
                                        <p>Eugenics ToRCH Series</p>
                                    </a>
                                </li>
                        	                            	<li>
                                	<a href="product_show.php?id=6">
                                    	<div class="pro_img">
                                            <img src="../upimg/2018070812474069.png" />
                                        </div>
                                        <p>Flow series</p>
                                    </a>
                                </li>
                        	                            	<li>
                                	<a href="product_show.php?id=5">
                                    	<div class="pro_img">
                                            <img src="../upimg/2018070812471966.png" />
                                        </div>
                                        <p>Infectious disease series</p>
                                    </a>
                                </li>
                        	                            	<li>
                                	<a href="product_show.php?id=4">
                                    	<div class="pro_img">
                                            <img src="../upimg/2018070812464486.png" />
                                        </div>
                                        <p>Eugenics ToRCH Series</p>
                                    </a>
                                </li>
                        	                            	<li>
                                	<a href="product_show.php?id=3">
                                    	<div class="pro_img">
                                            <img src="../upimg/2018070812474069.png" />
                                        </div>
                                        <p>Flow series</p>
                                    </a>
                                </li>
                        	                            	<li>
                                	<a href="product_show.php?id=2">
                                    	<div class="pro_img">
                                            <img src="../upimg/2018070812471966.png" />
                                        </div>
                                        <p>Infectious disease series</p>
                                    </a>
                                </li>
                        	                            	<li>
                                	<a href="product_show.php?id=1">
                                    	<div class="pro_img">
                                            <img src="../upimg/2018070812464486.png" />
                                        </div>
                                        <p>Eugenics ToRCH Series</p>
                                    </a>
                                </li>
                        	                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="clear"></div>
                    <div class="fenye" align="center">
                    	<table  border="0" cellpadding="0" cellspacing="0" align="center">
                            <tr>
                                <td>
                                    <div class="pages"><ul><li class="nolink"><a>上一页</a></li><li class="current"><a>1</a></li><li class="nolink" style="margin:0;"><a>下一页</a></li></ul></div><style type="text/css">
					.pages {color: #aaa;padding:0;font-family:Verdana;font-size:12px;font-weight:bold;}
					.pages ul{list-style: none;margin:0px;padding:0px;text-align:left;}
					.pages li {display: inline-block;*display:inline;margin: 0 5px 0 0;}
					.pages li a {color:#0e5bb7;border: 1px solid #ddd;background-color:#ffffff;text-decoration: none;padding:1px 5px 2px 5px;}
					.pages li a:hover {color:#ffffff;border:1px solid #0e4f9d;background:#0e5bb7;}
					.pages li.current a{color:#ffffff;border:1px solid #063267;background:#0e4f9d;}
					.pages li.current a:hover{color:#ffffff;border:1px solid #063267;background:#0e4f9d;}
					.pages li.nolink  a{color:#CCCCCC;border:1px solid #F0F0F0;background:#ffffff;}
					.pages li.nolink  a:hover{color:#CCCCCC;border:1px solid #F0F0F0;background:#ffffff;}
				  </style>                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
    <!--联系我们  深圳科隆生物新材料有限公司-->
<div class="us">
	<div class="div1200">
    	<div class="us_a fl">
        	<h1>contact us</h1>
            <div class="us_form">
            	 <form name="formb" id="formb" method="post" action="message.php?act=post" onsubmit="return checkform('formb')">
                	<input type="text" class="text1" placeholder="Name" style="color:#fff;" name="rename" />
                    <select class="select" name="title">
                    	<option style="color:#c7cccc;" value="">Choose country</option>
                                            	<option style="color:#c7cccc;" value="China">China</option>
                                            </select>
                	<input type="text" class="text1" placeholder="company name" style="color:#fff;" name="compname" />
                	<input type="text" class="text1 text2" placeholder="mailbox" style="color:#fff;" name="email" />
                    <textarea class="textarea" placeholder="Your information" style="color:#fff;" name="z_body"></textarea>
                    <input type="submit" class="lxwm_btn fr" value="submit" />
                    <div class="clear"></div>
                </form>
            </div>
        </div>

        <!--底部联系我们-->
        <div class="us_b fl">

        	        	<h1>Shenzhen Klon New Biomaterials Co., Ltd. </h1>
            <p>
            	Floor 3,Block 5,Bio Vally Bioscience<br />Industrial Park,Jinye Rd. 140.<br /><br />Zip code: 518000<br /><br />Phone: 13537778661 Dr.wang<br />            </p>
        </div>
        <div class="clear"></div>
    </div>
</div>

<div class="foot">
    	<div class="div1200">
        	<p></p>
        </div>
    </div>
</div></body>
</html>
