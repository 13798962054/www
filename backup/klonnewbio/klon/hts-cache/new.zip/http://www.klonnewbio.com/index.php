<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/animate.min.css" type="text/css" rel="stylesheet" />
<script src="js/jquery-1.11.0.min.js" type="text/javascript"></script>
<script src="js/responsiveslides.min.js" type="text/javascript"></script>
<title>深圳科隆生物新材料有限公司</title>
<meta name="keywords" content="深圳科隆生物新材料有限公司"/>
<meta name="description" content="深圳科隆生物新材料有限公司"/>
<script>
	window.onload = function(){
		document.getElementsByClassName("us")[0].getElementsByTagName("p")[0].innerHTML = "深圳市大鹏新区金业大道140号<br/>国际生物谷生命科学产业园B5栋301<br/>邮编：518000<br/>电话：13537778661<br/><br/>电子邮箱：klonnewbio@klonnewbio.com"
		document.getElementsByClassName("lxwm")[0].innerHTML = "<h3>联系我们</h3><p></p><p>公司名：深圳科隆生物新材料有限公司 <br>联系人：王博士</p><p>	技术咨询热线：13537778661</p><p>售后电话：13537778661</p><p>Email：klonnewbio@klonnewbio.com</p><p>Web： www.klonnewbio.com</p><p></p>"
	}
</script></head>

<body>
	<div class="wrap">
    	
        <!--header-->
        <div class="header">
     <div style="float: right;margin-right: 55px;font-size: 14px;margin-top: 35px;"><a href="#">中文&nbsp;</a>/<a href="en/">&nbsp;English</a></div>
        	<div class="div1200">
            	<div class="logo fl"><a href=""><img src="images/index_05.png" /></a></div>
                <div class="nav fr">
                	<ul>
                    	<li class="on">
                            <a href="index.php">
                                首页
                            </a>
                        </li>
                    	<li >
                            <a href="about.php">
                                关于我们
                            </a>
                        </li>
                    	<li >
                            <a href="product.php">
                                产品中心
                            </a>
                        </li>
                    	<li >
                            <a href="dzfw.php">
                                定制服务
                            </a>
                        </li>
                    	<li >
                            <a href="news.php">
                                新闻动态
                            </a>
                        </li>
                    	<li >
                            <a href="swhz.php">
                                商务合作
                            </a>
                        </li>
                    	<li >
                            <a href="job.php">
                                招贤纳士
                            </a>
                        </li>
                    	<li >
                            <a href="contact.php">
                                联系我们
                            </a>
                        </li>                                                                             
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>

            </div>

        </div>        
        <!--banner-->
            <div class="callbacks_container">
        <ul class="rslides" id="slider">
                            <li>
                    <a href="javascript:;" >
                        <img src="upimg/2018070816213270.jpg" border='0' width="1920" height="800">
                    </a>
                </li>
                            <li>
                    <a href="javascript:;" >
                        <img src="upimg/2018070816211297.jpg" border='0' width="1920" height="800">
                    </a>
                </li>
                    </ul>
    </div>
    <script type="text/javascript">
    $hd = $;
    $hd(function () {
        $hd("#slider").responsiveSlides({auto: true,pager: false,nav: true,speed: 500,timeout:4000,pager: true, pauseControls: true,namespace: "callbacks"});
    });
    </script>
        
        <!--公司简介-->
        <div class="company">
        	<div class="div1200">
            	<div class="tit">
                	<h1>公司简介</h1>
                    <p class="slideInUp wow animated">搜索超过30000种的诊断原料</p>
                </div>
                <div class="search">
                	<div class="search_form">
                    	<form>
                        	<input type="text" class="text" placeholder="请输入搜索关键字" />
                            <input type="button" class="btn" />
                        </form>
                    </div>
                </div>
                <div class="company_list">
                	<div class="company_a fl">
                	                		<img src="upimg/2018070423072772.jpg" />
                	</div>
                    <div class="company_b fl">
                    	<p></p>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="more">
                	<a href="about.php">查看<i></i>详情</a>
                </div>
            </div>
        </div>
        
        <!--各类抗原抗体-->
        <div class="type">
        	<div class="div1200">
            	<div class="tit">
                	<h1>各类抗原抗体</h1>
                    <p class="slideInUp wow animated">搜索超过30000种的诊断原料</p>
                    <a href="product.php">查阅产品资料</a>
                </div>
                <div class="type_list">
                	<ul>
                                            	<li>
                        	<a href="product.php?lm=1">
                            	<div class="type_img">
                                    <img src="upimg/2018070815102091.png" />
                                </div>
                                <p>优生优育ToRCH系列</p>
                            </a>
                        </li>
                    	                    	<li>
                        	<a href="product.php?lm=2">
                            	<div class="type_img">
                                    <img src="upimg/2018070815115083.png" />
                                </div>
                                <p>自身免疫系列</p>
                            </a>
                        </li>
                    	                    	<li>
                        	<a href="product.php?lm=3">
                            	<div class="type_img">
                                    <img src="upimg/2018070815110358.png" />
                                </div>
                                <p>流式系列</p>
                            </a>
                        </li>
                    	                    	<li>
                        	<a href="product.php?lm=4">
                            	<div class="type_img">
                                    <img src="upimg/2018070815112282.png" />
                                </div>
                                <p>心脑血管系列</p>
                            </a>
                        </li>
                    	                    	<li>
                        	<a href="product.php?lm=5">
                            	<div class="type_img">
                                    <img src="upimg/2018070815120573.png" />
                                </div>
                                <p>肿瘤系列</p>
                            </a>
                        </li>
                    	                    	<li>
                        	<a href="product.php?lm=6">
                            	<div class="type_img">
                                    <img src="upimg/2018070815104337.png" />
                                </div>
                                <p>传染病系列</p>
                            </a>
                        </li>
                    	                    	<li>
                        	<a href="product.php?lm=7">
                            	<div class="type_img">
                                    <img src="upimg/2018070815131597.png" />
                                </div>
                                <p>病理系列</p>
                            </a>
                        </li>
                    	                    	<li>
                        	<a href="product.php?lm=8">
                            	<div class="type_img">
                                    <img src="upimg/2018070815133627.png" />
                                </div>
                                <p>其它疾病系列</p>
                            </a>
                        </li>
                    	                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        
        <!--四大优势-->
        <div class="sdys">
        	<div class="div1200">
            	<div class="tit">
                	<h1>四大优势</h1>
                    <p class="slideInUp wow animated">搜索超过30000种的诊断原料</p>
                </div>
            </div>
            <div class="sdys_list">
                <div class="div930">
                    <ul>
                    			                    <li class="slideInLeft wow animated">
		                        <div class="sdys_a fl">
		                        	<img src="upimg/2018070422524011.png" />
		                        </div>
		                        <div class="sdys_b fl">
		                        	<h6>服务优势</h6>
		                            <p>公司目前已与多家欧美著名原料供应商和国内IVD产品生产商建立起长期、友好的合作关系。</p>
		                        </div>
		                        <div class="clear"></div>
		                    </li>
                        		                    <li class="slideInLeft wow animated">
		                        <div class="sdys_a fl">
		                        	<img src="upimg/2018070422522175.png" />
		                        </div>
		                        <div class="sdys_b fl">
		                        	<h6>渠道优势</h6>
		                            <p>公司以提升国产IVD试剂产品质量为使命，服务于各大国内IVD厂商，寻求通过国际合作和全球采购的方式，为国内合作伙伴提供优质原料试剂和最佳技术解决方案。</p>
		                        </div>
		                        <div class="clear"></div>
		                    </li>
                        		                    <li class="slideInLeft wow animated">
		                        <div class="sdys_a fl">
		                        	<img src="upimg/2018070422520056.png" />
		                        </div>
		                        <div class="sdys_b fl">
		                        	<h6>平台优势</h6>
		                            <p>公司与欧美Bangslabs, Polysciences, Spherotech, Micormod, Biopal等著名微球公司建立友好的合作关系，是其指定的大陆及香港地区代理及技术支持商。</p>
		                        </div>
		                        <div class="clear"></div>
		                    </li>
                        		                    <li class="slideInLeft wow animated">
		                        <div class="sdys_a fl">
		                        	<img src="upimg/2018070422512331.png" />
		                        </div>
		                        <div class="sdys_b fl">
		                        	<h6>技术优势</h6>
		                            <p>公司现有核心研发人员博士两名，都具备长期在国外实验室，公司从事产品研发的丰富经验。为提升研发水平，公司还定期派员至国外学习有关纳米微球应用的最新技术。</p>
		                        </div>
		                        <div class="clear"></div>
		                    </li>
                                                <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        
        <!--产品动态  行业动态  联系我们-->
        <div class="con">
        	<div class="div1200">
            	<div class="cpdt fl">
                	<h3>公司动态</h3>
                    <div class="cpdt_list">
                    	<ul>
                                                        	<li>
                                    <a href="news_show.php?id=7">
                                        <i></i>
                                        <span>
                                            2018-07                                        </span>
                                        公司新闻                                     </a>
                                </li>
                        	                            	<li>
                                    <a href="news_show.php?id=5">
                                        <i></i>
                                        <span>
                                            2018-07                                        </span>
                                        公司新闻                                     </a>
                                </li>
                        	                            	<li>
                                    <a href="news_show.php?id=3">
                                        <i></i>
                                        <span>
                                            2018-07                                        </span>
                                        公司新闻                                     </a>
                                </li>
                        	                            	<li>
                                    <a href="news_show.php?id=1">
                                        <i></i>
                                        <span>
                                            2018-07                                        </span>
                                        公司新闻                                     </a>
                                </li>
                        	                        </ul>
                        <div class="gd">
                        	<a href="news.php">了解更多>></a>
                        </div>
                    </div>
                </div>


            	<div class="cpdt hydt fl">
                	<h3>行业动态</h3>
                    <div class="cpdt_list">
                    	<ul>
                        	                                 <li>
                                    <a href="news_show.php?id=8">
                                        <i></i>
                                        <span>
                                            2018-07                                        </span>
                                        行业新闻                                     </a>
                                </li>
                                                            <li>
                                    <a href="news_show.php?id=6">
                                        <i></i>
                                        <span>
                                            2018-07                                        </span>
                                        行业新闻                                     </a>
                                </li>
                                                            <li>
                                    <a href="news_show.php?id=4">
                                        <i></i>
                                        <span>
                                            2018-07                                        </span>
                                        行业新闻                                     </a>
                                </li>
                                                            <li>
                                    <a href="news_show.php?id=2">
                                        <i></i>
                                        <span>
                                            2018-07                                        </span>
                                        行业新闻                                     </a>
                                </li>
                                                    </ul>
                        <div class="gd">
                        	<a href="news.php">了解更多>></a>
                        </div>
                    </div>
                </div>

                <!--联系我们-->
                <div class="lxwm fr">
                	                	<h3>联系我们</h3>
                    
                	<p><p>
	公司名：深圳科隆生物新材料有限公司 <br />
联系人：王博士
</p>
<p>
	技术咨询热线：13537778661
</p>
<p>
	售后电话：13537778661
</p>
<p>
	Email：klonnewbio@klonnewbio.com
</p>
<p>
	Web： www.klonnewbio.com
</p></p>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        
        <!--技术服务-->
        <div class="jsfw">
        	<img src="images/index_48.png" />
            <div class="jsfw_wz">
                <div class="div1200">
                	                    <h1>技术服务</h1>
                    <p class="slideInUp wow animated">专业从事体外诊断用微球、抗原、抗体和<br />标记酶等试剂原料的研发、销售和相关的技术服务。</p>
                    <a href="javascript:;">查询</a>
                </div>
            </div>
        </div>

    <!--foot-->
    <!--联系我们  深圳科隆生物新材料有限公司-->
<div class="us">
	<div class="div1200">
    	<div class="us_a fl">
        	<h1>联系我们</h1>
            <div class="us_form">
            	 <form name="formb" id="formb" method="post" action="message.php?act=post" onsubmit="return checkform('formb')">
                	<input type="text" class="text1" placeholder="姓名" style="color:#fff;" name="rename" />
                    <select class="select" name="title">
                    	<option style="color:#c7cccc;" value="">选择国别</option>
                                            	<option style="color:#c7cccc;" value="中国">中国</option>
                                            </select>
                	<input type="text" class="text1" placeholder="公司名称" style="color:#fff;" name="compname" />
                	<input type="text" class="text1 text2" placeholder="邮箱" style="color:#fff;" name="email" />
                    <textarea class="textarea" placeholder="你的信息" style="color:#fff;" name="z_body"></textarea>
                    <input type="submit" class="lxwm_btn fr" value="提交" />
                    <div class="clear"></div>
                </form>
            </div>
        </div>

        <!--底部联系我们-->
        <div class="us_b fl">

        	        	<h1>深圳科隆生物新材料有限公司</h1>
            <p>
            	深圳市大鹏新区金业大道140号<br />国际生物谷生命科学产业园B5栋3层<br />邮编 518000 <br />电话: 13537778661 王博士<br /><br />电子邮件:<br />klonnewbio@klonnewbio.com<br />+86-13537778661<br /><br />订货:<br />klonnewbio@klonnewbio.com            </p>
        </div>
        <div class="clear"></div>
    </div>
</div>

<div class="foot">
    	<div class="div1200">
        	<p>&copy; Copyright 2018 深圳科隆生物新材料有限公司 <a href="http://www.miit.gov.cn/" target="_blank">粤ICP备18065683号-1号</a> 网站建设：<a href="http://www.heyou51.com" target="_blank">合优网络</a></p>
        </div>
    </div>
</div>    <script src="js/wow.min.js" type="text/javascript"></script>
    <script>
    $(document).ready(function(){
    	var wow = new WOW({
    		boxClass:'wow',
    		animateClass:'animated',
    		offset:200,
    		mobile: true,
    		live: true,
    	});
    	wow.init();
    })
    </script>
</body>
</html>
