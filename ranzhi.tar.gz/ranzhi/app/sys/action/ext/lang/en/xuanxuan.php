<?php
$lang->action->label->loginXuanxuan  = 'Login Xuanxuan';
$lang->action->label->logoutXuanxuan = 'Logout Xuanxuan';
