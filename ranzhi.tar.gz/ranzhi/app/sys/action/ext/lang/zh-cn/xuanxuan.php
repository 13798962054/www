<?php
$lang->action->label->loginxuanxuan  = '登录喧喧';
$lang->action->label->logoutxuanxuan = '退出喧喧';
