<?php
$lang->action->label->loginxuanxuan  = '登錄喧喧';
$lang->action->label->logoutxuanxuan = '退出喧喧';
