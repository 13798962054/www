<?php
$config->group->require = new stdclass();
$config->group->require->create = 'name';
$config->group->require->edit   = 'name';
