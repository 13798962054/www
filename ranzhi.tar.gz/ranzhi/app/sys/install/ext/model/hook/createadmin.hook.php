<?php
$this->loadModel('upgrade')->installSSOEntry();
