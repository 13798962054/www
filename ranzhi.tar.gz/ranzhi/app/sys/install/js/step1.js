$(document).ready(function()
{
    /* Remove check failure notices. */
    if(v.wholeResult == 'ok')
    {
        $("tr>th:last-child, .f-12px").remove();
    }
});
