$(document).ready(function()
{
    $.setAjaxForm('#adminForm');
    $('#account').focus();
})
