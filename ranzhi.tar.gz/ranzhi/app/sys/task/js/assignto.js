$(document).ready(function()
{
    $.setAjaxForm('#assignToForm');
})
