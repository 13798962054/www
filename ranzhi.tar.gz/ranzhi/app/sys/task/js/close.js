$(document).ready(function()
{
    $.setAjaxForm('#closeForm');
})
