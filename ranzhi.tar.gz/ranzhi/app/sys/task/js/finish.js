$(document).ready(function()
{
    $.setAjaxForm('#finishForm');
})
