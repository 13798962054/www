$(document).ready(function()
{
    $.setAjaxForm('#estimateForm');
})
