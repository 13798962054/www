$(document).ready(function()
{
    $('#commentBox').load( createLink('message', 'comment', 'objectType=blog&objectID=' + v.articleID) );  
});
