<?php
$lang->team->menuOrder[5]  = 'dashboard';
$lang->team->menuOrder[10] = 'forum';
$lang->team->menuOrder[15] = 'blog';
$lang->team->menuOrder[20] = 'user';
$lang->team->menuOrder[25] = 'company';
$lang->team->menuOrder[30] = 'setting';

$lang->blog->menuOrder[5]  = 'index';
$lang->blog->menuOrder[10] = 'category';

$lang->setting->menuOrder[5]  = 'board';
$lang->setting->menuOrder[10] = 'blog';
$lang->setting->menuOrder[15] = 'dept';
$lang->setting->menuOrder[20] = 'role';
