<?php
$config->reply->editor = new stdclass();
$config->reply->editor->edit = array('id' => 'content', 'tools' => 'simple');
