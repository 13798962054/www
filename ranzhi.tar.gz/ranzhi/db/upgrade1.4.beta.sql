UPDATE sys_block SET grid = '4';

ALTER TABLE sys_task 
CHANGE `estimate` `estimate` decimal(12,1) unsigned NOT NULL,
CHANGE `consumed` `consumed` decimal(12,1) unsigned NOT NULL,
CHANGE `left` `left` decimal(12,1) unsigned NOT NULL;
