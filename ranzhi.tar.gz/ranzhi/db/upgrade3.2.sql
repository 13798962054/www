ALTER TABLE `sys_schema` add `product` char(10) NOT NULL;
