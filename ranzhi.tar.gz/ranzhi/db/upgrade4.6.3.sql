UPDATE `sys_team` SET `role` = '' WHERE `type` = 'task' AND `role` = 'member';
