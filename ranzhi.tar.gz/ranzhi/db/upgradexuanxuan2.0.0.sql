ALTER TABLE `sys_entry` ADD `sso` enum('0', '1') NOT NULL DEFAULT '0';
