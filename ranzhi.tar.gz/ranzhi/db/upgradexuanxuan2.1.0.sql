ALTER TABLE `sys_user` ADD `clientLang` varchar(10) NOT NULL DEFAULT 'zh-cn';
