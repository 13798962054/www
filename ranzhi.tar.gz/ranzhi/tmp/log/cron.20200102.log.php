<?php
 die();
17:40:23 task 5 executed,
command: appName=sys&moduleName=queue&methodName=getqueue.
return : .
output : ok

17:40:23 task 6 executed,
command: appName=sys&moduleName=queue&methodName=additional.
return : .
output : ok

17:42:47 task 5 executed,
command: appName=sys&moduleName=queue&methodName=getqueue.
return : .
output : ok

17:45:15 task 5 executed,
command: appName=sys&moduleName=queue&methodName=getqueue.
return : .
output : ok

17:47:25 task 5 executed,
command: appName=sys&moduleName=queue&methodName=getqueue.
return : .
output : ok

