<?php
 die();
9:24:15 task 5 executed,
command: appName=sys&moduleName=queue&methodName=getqueue.
return : .
output : ok

9:30:42 task 5 executed,
command: appName=sys&moduleName=queue&methodName=getqueue.
return : .
output : ok

9:30:42 task 6 executed,
command: appName=sys&moduleName=queue&methodName=additional.
return : .
output : ok

