<?php
 die();
9:21:22 task 5 executed,
command: appName=sys&moduleName=queue&methodName=getqueue.
return : .
output : ok

