<?php
 die();
?>

16:55:48 A session had already been started - ignoring session_start() in framework/base/router.class.php on line 817 when visiting 

16:55:51 A session had already been started - ignoring session_start() in framework/base/router.class.php on line 817 when visiting 

16:55:54 A session had already been started - ignoring session_start() in framework/base/router.class.php on line 817 when visiting 

16:55:55 A session had already been started - ignoring session_start() in framework/base/router.class.php on line 817 when visiting 

16:55:57 A session had already been started - ignoring session_start() in framework/base/router.class.php on line 817 when visiting 

16:56:03 A session had already been started - ignoring session_start() in framework/base/router.class.php on line 817 when visiting 
