<?php
 die();
?>
20191227 16:55:48: /sys/install.php

20191227 16:55:51: /sys/install.php

20191227 16:55:54: /sys/install.php?m=install&f=step0

20191227 16:55:55: /sys/install.php?m=install&f=step1

20191227 16:55:57: /sys/install.php?m=install&f=step2

20191227 16:56:03: /sys/install.php?m=install&f=step3

